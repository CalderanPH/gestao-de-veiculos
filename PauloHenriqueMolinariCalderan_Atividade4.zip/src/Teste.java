import jdk.swing.interop.SwingInterOpUtils;
import java.lang.NumberFormatException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Teste {
    private static Passeio passeio = new Passeio();
    private static Carga carga = new Carga();

    private static Passeio vetPasseio[] = new Passeio[5];
    private static Carga vetCarga[] = new Carga[5];

    private static Leitura l = new Leitura();


    public static void main(String[] args) {

        boolean continua = true;
        int opcao = 0;

        while (continua){
            System.out.println("\n ===================SISTEM DE GESTÃO DE VEÍCULOS - MENU PRINCIPAL ================\n");
            System.out.println("   |-------------------------------------------|");
            System.out.println("   | 1. Cadastrar Veículo de Passeio           |");
            System.out.println("   | 2. Cadastrar Veículo de Carga             |");
            System.out.println("   | 3. Imprimir todos os Veículos de Passeio  |");
            System.out.println("   | 4. Imprimir todos os Veículos de Carga    |");
            System.out.println("   | 5. Imprimir Veículo de Passeio pela Placa |");
            System.out.println("   | 6. Imprimir Veículo de Carga pela Placa   |");
            System.out.println("   | 7. Sair do Sistema                        |");
            System.out.println("   |-------------------------------------------|");
            System.out.println("\n Digite o número de uma opção! \n ");


            try {
                opcao = Integer.parseInt(l.entDados("Digite o número da opção desejada!"));
            }
            catch (NumberFormatException nfe) {
                System.out.println("Deve ser um número inteiro - PRESS -> ENTER <- para recomeçar");
                l.entDados("");

                continue;
            }

            switch (opcao){
                //Cadastrar Veículo de Passeio
                case 1:
                    for (int i = achaVagoPasseio(); i < vetPasseio.length; i++){
                        if(i == -1){
                            l.entDados("Cadastro de Veículos de Passeio está cheio - PRESS -> ENTER <- para recomeçar");
                            break;
                        }

                        passeio = new Passeio();
                        vetPasseio[i] = cadPasseio(passeio);
                        l.entDados("O veículo de passeio armazenado na posição " + i + "do vetor - PRESS -> ENTER <-");
                        String respPass = l.entDados("Deseja cadastrar outro Passeio?  S/N");
                        if (respPass.equalsIgnoreCase("n")){
                            break;
                        }
                        if (achaVagoPasseio() == -1){
                            l.entDados("Cadastro de Veículos de Passeio está cheio - PRESS -> ENTER <- para recomeçar");
                            break;
                        }
                    }
                    break;

                    //Cadastrar Veículo de Carga
                case 2:
                    for (int i = achaVagoCarga(); i < vetCarga.length; i++){
                        if(i == -1){
                            l.entDados("Cadastro de Veículos de Carga está cheio - PRESS -> ENTER <- para recomeçar");
                            break;
                        }

                        carga = new Carga();
                        vetCarga[i] = cadCarga(carga);
                        l.entDados("O veículo de passeio armazenado na posição " + i + "do vetor - PRESS -> ENTER <-");
                        String respCarg = l.entDados("Deseja cadastrar outro Passeio?  S/N");
                        if (respCarg.equalsIgnoreCase("n")){
                            break;
                        }
                        if (achaVagoCarga() == -1){
                            l.entDados("Cadastro de Veículos de Passeio está cheio - PRESS -> ENTER <- para recomeçar");
                            break;
                        }
                    }
                    break;

                case 3:
                    System.out.println("\n Passeio - Impressão de todos veiculos");
                    for (int i = 0; i < vetPasseio.length; i++){
                        if(vetPasseio[i] != null){
                            impPasseio(vetPasseio[i], i);
                        }
                        else {
                            l.entDados("\n Sem mais Veículos de Passeio para imprimir - PRESS -> ENTER <-");
                        }
                    }
                    break;

                case 4:
                    System.out.println("Carga - impressão de todos veículos de carga");
                    for (int i = 0; i < vetCarga.length; i++){
                        if(vetCarga[i] != null){
                            impCarga(vetCarga[i], i);
                    }
                        else{
                            l.entDados("Sem mais veículos de carga para imprimir - PRESS -> ENTER <-");
                    }
                }break;

                case 5:
                    System.out.println("Consulta pela Placa - veiculos Passeio");
                    passeio = new Passeio();
                    boolean existPlacaPass = false;
                    String placaPass = l.entDados("Informe a placa a ser pesquisada: ");
                    passeio.setPlaca(placaPass);
                    for (int i = 0; i < vetPasseio.length; i++){
                        try {
                            if (vetPasseio[i].getPlaca().equalsIgnoreCase(passeio.getPlaca())) {
                                impPasseio(vetPasseio[i], i);
                                existPlacaPass = true;
                            }
                        }
                        catch (NullPointerException npe){
                        }
                    }
                    if(!existPlacaPass){
                        l.entDados("Não existe veiculo de Passeio com está Placa -PRESS -> ENTER <-");
                    }break;

                case 6:
                    System.out.println("Consulta pela Placa do veículo de Carga");
                    carga = new Carga();
                    boolean existPlacaCarg = false;
                    String placaCarg = l.entDados("Informe a placa à ser pesquisada");
                    carga.setPlaca(placaCarg);
                    for (int i = 0; i < vetCarga.length; i++){
                        try {
                            if (vetCarga[i].getPlaca().equalsIgnoreCase(carga.getPlaca())) {
                                impCarga(vetCarga[i], i);
                                existPlacaCarg = true;
                            }
                        }
                        catch (NullPointerException npe){
                        }
                    }
                    if(!existPlacaCarg){
                        l.entDados("Não existe veiculo de Carga com esta Placa - PRESS -> ENTER <-");
                    }
                    break;
                case 7:
                    continua = false;
                    break;

                default:
                    l.entDados("O valor deve ser de 1 ao 7 - PRESS -> ENTER <-");
                    break;
            }
        }
    }
    public static int achaVagoPasseio(){
        for (int i = 0; i < vetPasseio.length; i++){
            if (vetPasseio[i] == null){
                return i;
            }

        }return -1;
    }
    public static int achaVagoCarga() {
        for (int i = 0; i < vetCarga.length; i++) {
            if (vetCarga[i] == null) {
                return i;
            }

        } return -1;
    }
    public static Passeio cadPasseio(Passeio passeio){
        System.out.println("Cadastro de Veículos de Passeio");
        passeio.setModelo(l.entDados("Informe o Modelo do Veiculo...: "));
        passeio.setCor(l.entDados("Informe a cor do Veículo...: "));
        passeio.setMarca(l.entDados("Informe a Marca do Veiculo...: "));
        passeio.setQtdPassageiros(Integer.parseInt(l.entDados("Informe a quantidade de Passageiros...:")));
        passeio.setQtdRodas(Integer.parseInt(l.entDados("Informe a quantidade de rodas...:")));
        passeio.setPlaca(l.entDados("Informe a Placa do Veículo...: "));
        passeio.getMotor().setQtdPist(Integer.parseInt(l.entDados("Informe a quantidade de pistões...: ")));
        passeio.getMotor().setPontencia(Integer.parseInt(l.entDados("Informe a potencia do veículo...: ")));
        passeio.setVelocMax(Integer.parseInt(l.entDados("Informe a velocidade máxima...:")));

        return passeio;
    }
    public static Carga cadCarga(Carga carga){
        System.out.println("Cadastro de Veículos de Passeio");
        carga.setModelo(l.entDados("Informe o Modelo do Veiculo...: "));
        carga.setCor(l.entDados("Informe a cor do Veículo...: "));
        carga.setMarca(l.entDados("Informe a Marca do Veiculo...: "));
        carga.setQtdRodas(Integer.parseInt(l.entDados("Informe a quantidade de rodas...:")));
        carga.setPlaca(l.entDados("Informe a Placa do Veículo...: "));
        carga.getMotor().setQtdPist(Integer.parseInt(l.entDados("Informe a quantidade de pistões...: ")));
        carga.getMotor().setPontencia(Integer.parseInt(l.entDados("Informe a potencia do veículo...: ")));
        carga.setVelocMax(Integer.parseInt(l.entDados("Informe a velocidade máxima...:")));
        carga.setTara(Integer.parseInt(l.entDados("Informe a Tara do veículo...:")));
        carga.setCargaMax(Integer.parseInt(l.entDados("Informe a Carga máxima do veículo...:")));

        return carga;

    }

    public static void impPasseio(Passeio passeio, int i){
        System.out.println("Passeio amazenado no endereço....: " + i+ "(do vetor vet Passeio)");
        System.out.println("Quantidade de Passageiros.....: " + passeio.getQtdPassageiros());
        System.out.println("Placa...:" + passeio.getPlaca());
        System.out.println("Marca...:  " +passeio.getMarca());
        System.out.println("Modelo...: " + passeio.getModelo());
        System.out.println("Cor...: " + passeio.getCor());
        System.out.println("Quantidade de Rodas...: "+passeio.getQtdRodas());
        System.out.println("Velocidade máxima...:" + passeio.getVelocMax());
        System.out.println("Quantidade de Pistoes do motor...: "+passeio.getMotor().getQtdPist());
        System.out.println("Potencia do motor...: "+ passeio.getMotor().getPontencia());
        System.out.println("Quantidade total de Letras...: "+ passeio.calcular());
        passeio.calcVel();
    }
    public static void impCarga(Carga carga, int i){
        System.out.println("Passeio amazenado no endereço....: " + i+ "(do vetor vet Carga)");
        System.out.println("Placa...:" + carga.getPlaca());
        System.out.println("Marca...:  " +carga.getMarca());
        System.out.println("Modelo...: " + carga.getModelo());
        System.out.println("Cor...: " + carga.getCor());
        System.out.println("Quantidade de Rodas...: "+carga.getQtdRodas());
        System.out.println("Velocidade máxima...:" + carga.getVelocMax());
        System.out.println("Quantidade de Pistoes do motor...: "+carga.getMotor().getQtdPist());
        System.out.println("Potencia do motor...: "+ carga.getMotor().getPontencia());
        System.out.println("A tara...: "+ carga.getTara());
        System.out.println("A carga Máxima...: "+carga.getCargaMax());
        System.out.println("Quantidade total de Letras...: "+ carga.calcular());
        passeio.calcVel();
    }
}